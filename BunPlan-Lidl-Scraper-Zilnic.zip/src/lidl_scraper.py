#!/usr/bin/env python3
"""BunPlan - importator pentru lista oficiala de preturi Lidl Romania.

Sursa: https://www.lidl.ro/c/preturile-la-zi/s10019622
Download direct al fisierului XLSB public, fara autentificare sau evitare de protectii.
Nu ofera stoc pe locatie, poze ori preturi promotionale.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import re
import sys
import unicodedata
from collections import Counter
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from zoneinfo import ZoneInfo

import requests
from pyxlsb import open_workbook
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_DIR = Path(__file__).resolve().parent.parent
PRICE_URL = "https://www.lidl.ro/explore/assets/webPriceData/ro/preturiZilniceLidl.xlsb"
INFO_URL = "https://www.lidl.ro/c/preturile-la-zi/s10019622"
TZ = ZoneInfo("Europe/Bucharest")

# Lista pozitiva. Categoriile de cosmetice, tutun, hrana animale etc. NU se importa.
FOOD_CATEGORIES = {
    "bauturi", "branzeturi", "cafea", "carne si peste", "ceai", "cereale", "congelate",
    "conserve", "dulciuri si snackuri", "inghetata", "ingrediente pentru copt",
    "ketchup mustar sosuri", "lactate", "legume si fructe", "mezeluri",
    "miere dulceturi si alte creme", "mirodenii si condimente", "oua",
    "paine si patiserie", "paste fainoase", "proaspete", "produse de baza",
    "supe si baze pentru supe", "ulei unt margarina",
}
# Filtru pentru sectiunea Bauturi si denumiri de preparate alcoolice.
ALCOHOL_RE = re.compile(
    r"\b(?:bere|vin(?:uri)?|vodca|vodka|whisky|whiskey|gin|rom|lichior|prosecco|"
    r"sampanie|sampaniei|cidru|tequila|alcool|aperitiv alcoolic|coniac|brandy)\b", re.I
)
COLUMN_ALIASES = {
    "name": ("denumire comerciala", "denumire produs", "denumire", "produs"),
    "size": ("gramaj", "cantitate", "ambalaj"),
    "category": ("categorie", "categoria", "grupa"),
    "price": ("pret vanzare", "pret de vanzare", "pret", "pret ron"),
}
FIELDS = [
    "id", "name", "size", "category", "price_ron", "currency", "price_per_kg_ron",
    "price_per_l_ron", "image_url", "shop", "source_url", "observed_at", "price_scope",
    "stock_status", "is_promotion",
]


def normalized(s: object) -> str:
    s = unicodedata.normalize("NFKD", str(s or ""))
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return re.sub(r"\s+", " ", re.sub(r"[^a-zA-Z0-9]+", " ", s).strip().lower())


def euro_decimal_to_float(value: object) -> float | None:
    """Citeste 12.49 / '12,49' / '1.234,56' fara aproximari binare."""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float, Decimal)):
        try:
            d = Decimal(str(value))
            return float(d.quantize(Decimal("0.01"))) if 0 < d < 100000 else None
        except InvalidOperation:
            return None
    s = str(value).strip().replace("\u00a0", "").replace(" ", "")
    s = re.sub(r"(?i)(ron|lei)$", "", s)
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        d = Decimal(s)
        return float(d.quantize(Decimal("0.01"))) if 0 < d < 100000 else None
    except InvalidOperation:
        return None


def extract_headers(rows: list[list[object]]) -> tuple[int, dict[str, int]]:
    """Cauta antetul din foaia XLSB chiar daca sunt randuri de titlu inainte."""
    for idx, row in enumerate(rows[:75]):
        names = [normalized(v) for v in row]
        cols: dict[str, int] = {}
        for wanted, aliases in COLUMN_ALIASES.items():
            for col, text in enumerate(names):
                if text in aliases or any(text.startswith(alias + " ") for alias in aliases):
                    cols[wanted] = col
                    break
        if len(cols) == 4:
            return idx, cols
    raise ValueError("Antetul XLSB nu contine coloanele asteptate: Denumire comerciala, Gramaj, Categorie, Pret vanzare")


def safe_cell(row: list[object], column: int) -> object:
    return row[column] if column < len(row) else None


def parse_size_price(size: str, price: float) -> tuple[float | None, float | None]:
    """Pret informativ la 1 kg / 1 L, DOAR daca gramajul poate fi interpretat clar."""
    s = re.sub(r"\s+", "", str(size).lower().replace(",", ".").replace("×", "x"))
    if not s:
        return None, None
    if "perkg" in s or s == "kg":
        return price, None
    if "perl" in s or s == "l":
        return None, price
    m = re.fullmatch(r"(?:(\d+)x)?(\d+(?:[\.,]\d+)?)(kg|g|ml|l)", s)
    if not m:
        return None, None
    mult = int(m.group(1) or 1)
    num = float(m.group(2).replace(",", ".")) * mult
    unit = m.group(3)
    denominator = (num * (1000 if unit in ("kg", "l") else 1))
    if denominator <= 0:
        return None, None
    price_std = round(price * 1000 / denominator, 2)
    return (price_std, None) if unit in ("kg", "g") else (None, price_std)


def is_food(category: str, name: str) -> bool:
    c = normalized(category)
    if c not in FOOD_CATEGORIES:
        return False
    if ALCOHOL_RE.search(normalized(name)):
        return False
    return True


def product_id(name: str, size: str, category: str) -> str:
    key = "|".join([normalized(name), normalized(size).replace(" ", ""), normalized(category)])
    return "lidl-" + hashlib.sha256(key.encode("utf-8")).hexdigest()[:18]


def parse_table(raw_rows: list[list[object]], observed_at: str, image_map: dict[str, str] | None = None) -> tuple[list[dict], dict]:
    header_idx, cols = extract_headers(raw_rows)
    items: dict[str, dict] = {}
    categories = Counter()
    conflicts = []
    ambiguous_ids = set()
    total_valid = 0
    for row in raw_rows[header_idx + 1:]:
        name = str(safe_cell(row, cols["name"]) or "").strip()
        size = str(safe_cell(row, cols["size"]) or "").strip()
        category = str(safe_cell(row, cols["category"]) or "").strip()
        price = euro_decimal_to_float(safe_cell(row, cols["price"]))
        if not name or not category or price is None:
            continue
        total_valid += 1
        categories[category] += 1
        if not is_food(category, name):
            continue
        pid = product_id(name, size, category)
        kg_price, l_price = parse_size_price(size, price)
        item = {
            "id": pid, "name": name, "size": size, "category": category,
            "price_ron": price, "currency": "RON",
            "price_per_kg_ron": kg_price, "price_per_l_ron": l_price,
            "image_url": (image_map or {}).get(pid),
            "shop": "Lidl", "source_url": PRICE_URL, "observed_at": observed_at,
            "price_scope": "sortiment_permanent_pret_publicat_national",
            "stock_status": "unknown", "is_promotion": False,
        }
        if pid in ambiguous_ids:
            continue
        if pid in items and items[pid]["price_ron"] != price:
            # Fara SKU oficial, doua randuri cu aceeasi identitate dar pret diferit sunt ambigue.
            # Excludem produsul din export; NU alegem arbitrar pretul minim.
            conflicts.append({"id": pid, "name": name, "prices": [items[pid]["price_ron"], price]})
            ambiguous_ids.add(pid)
        else:
            items[pid] = item
    for ambiguity in conflicts:
        items.pop(ambiguity["id"], None)
    products = sorted(items.values(), key=lambda x: (normalized(x["category"]), normalized(x["name"]), x["id"]))
    stats = {"all_categories": dict(categories), "valid_rows_all_categories": total_valid,
             "food_products": len(products), "duplicate_price_conflicts": conflicts[:50]}
    return products, stats


def parse_xlsb(blob: bytes, observed_at: str, image_map: dict[str, str] | None = None) -> tuple[list[dict], dict]:
    if not blob.startswith(b"PK"):
        raise ValueError("Fisierul primit nu este un workbook XLSB (ZIP/Office).")
    with open_workbook(io.BytesIO(blob)) as book:
        names = book.sheets
        sheet_name = "EPEL" if "EPEL" in names else names[0]
        with book.get_sheet(sheet_name) as sheet:
            rows = [[cell.v for cell in row] for row in sheet.rows(sparse=False)]
    return parse_table(rows, observed_at, image_map)


def fetch_blob(url: str = PRICE_URL) -> bytes:
    session = requests.Session()
    retry = Retry(total=3, backoff_factor=1.5, status_forcelist=[429, 500, 502, 503, 504])
    session.mount("https://", HTTPAdapter(max_retries=retry))
    response = session.get(url, timeout=(12, 40), headers={"User-Agent": "BunPlanDailyPrices/1.0 (public price-list importer; https://www.lidl.ro/c/preturile-la-zi/s10019622)"})
    response.raise_for_status()
    content = response.content
    if len(content) > 20 * 1024 * 1024 or len(content) < 100:
        raise ValueError(f"Dimensiune XLSB suspecta: {len(content)} bytes")
    return content


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default


def write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def write_csv(path: Path, products: list[dict]):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(products)
    os.replace(tmp, path)


def make_changes(old: list[dict], current: list[dict], observed_at: str) -> list[dict]:
    old_by_id = {p["id"]: p for p in old}
    current_by_id = {p["id"]: p for p in current}
    events = []
    for pid, p in current_by_id.items():
        prev = old_by_id.get(pid)
        if prev is None:
            kind = "added_to_pricelist"
        elif prev.get("price_ron") != p.get("price_ron"):
            kind = "price_changed"
        else:
            continue
        events.append({"observed_at": observed_at, "change_type": kind, "id": pid,
                       "name": p["name"], "category": p["category"],
                       "old_price_ron": prev.get("price_ron") if prev else None,
                       "new_price_ron": p["price_ron"]})
    for pid in old_by_id.keys() - current_by_id.keys():
        prev = old_by_id[pid]
        events.append({"observed_at": observed_at, "change_type": "absent_from_new_pricelist",
                       "id": pid, "name": prev["name"], "category": prev["category"],
                       "old_price_ron": prev["price_ron"], "new_price_ron": None})
    return sorted(events, key=lambda e: (e["change_type"], e["name"], e["id"]))


def append_history(path: Path, events: list[dict]):
    if not events:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    columns = ["observed_at", "change_type", "id", "name", "category", "old_price_ron", "new_price_ron"]
    existing = path.exists()
    with path.open("a", newline="", encoding="utf-8" if existing else "utf-8-sig") as fp:
        out = csv.DictWriter(fp, fieldnames=columns)
        if not existing:
            out.writeheader()
        out.writerows(events)


def run(output: Path, input_file: Path | None = None, min_products: int = 200, image_map_file: Path | None = None) -> dict:
    now = datetime.now(TZ).isoformat(timespec="seconds")
    source = input_file.read_bytes() if input_file else fetch_blob()
    digest = hashlib.sha256(source).hexdigest()
    image_map = read_json(image_map_file, {}) if image_map_file else {}
    products, stats = parse_xlsb(source, now, image_map)
    if len(products) < min_products:
        raise ValueError(f"Validarea a esuat: doar {len(products)} produse alimentare (< {min_products}). Pastram datele precedente.")
    data_dir = output / "data"
    docs_dir = output / "docs" / "api" / "lidl"
    before = read_json(data_dir / "lidl_products.json", {}).get("products", [])
    changes = make_changes(before, products, now)
    summary = Counter(e["change_type"] for e in changes)
    old_meta = read_json(data_dir / "lidl_meta.json", {})
    meta = {
        "store": "Lidl Romania", "checked_at": now, "source_url": PRICE_URL,
        "source_information": INFO_URL, "source_sha256": digest,
        "source_changed_since_previous_check": digest != old_meta.get("source_sha256"),
        "product_count": len(products), "total_rows_in_file": stats["valid_rows_all_categories"],
        "categories": sorted({p["category"] for p in products}),
        "changes_since_previous_check": dict(summary),
        "stock_available": False, "promotional_prices_included": False,
        "product_images_available_in_source": False,
        "note": "Sortiment permanent, preturi publicate national; nu stoc local. SGR exclus. Produsele absente din fisier nu sunt neaparat epuizate.",
        "conflicting_rows_skipped": len(stats["duplicate_price_conflicts"]),
    }
    payload = {"meta": meta, "products": products}
    for base in (data_dir, docs_dir):
        write_json(base / "lidl_products.json", payload)
        write_json(base / "lidl_meta.json", meta)
        write_json(base / "lidl_changes.json", changes)
        write_csv(base / "lidl_products.csv", products)
    append_history(data_dir / "lidl_price_history.csv", changes)
    if stats["duplicate_price_conflicts"]:
        write_json(data_dir / "lidl_conflicts.json", stats["duplicate_price_conflicts"])
    print(f"[{now}] {len(products)} produse alimentare; actualizari: {dict(summary)}; SHA256: {digest[:12]}")
    return meta


def main():
    parser = argparse.ArgumentParser(description="Importa zilnic lista publica XLSB Lidl Romania pentru BunPlan")
    parser.add_argument("--output", type=Path, default=BASE_DIR)
    parser.add_argument("--input-file", type=Path, help="XLSB local pentru rulare offline")
    parser.add_argument("--image-map", type=Path, default=BASE_DIR / "config" / "images.json")
    parser.add_argument("--min-products", type=int, default=200)
    args = parser.parse_args()
    try:
        run(args.output, args.input_file, args.min_products, args.image_map)
    except Exception as exc:
        print(f"EROARE: {exc} — nu am modificat catalogul publicat.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
