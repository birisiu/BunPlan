# BunPlan — Lidl Romania Daily Food Price Importer

**Scop:** sa construiasca zilnic catalogul alimentar Lidl pentru BunPlan, din sursa publica oficiala: [Preturile la zi](https://www.lidl.ro/c/preturile-la-zi/s10019622).

Lidl publica **luni–vineri** un fisier `.xlsb` cu preturile sortimentului permanent (toate magazinele din Romania, conform textului oficial), la:  
`https://www.lidl.ro/explore/assets/webPriceData/ro/preturiZilniceLidl.xlsb`

## Ce extrage

- Denumirea produsului, gramaj, categorie, pret in lei, cost/kg sau L (cand gramajul permite).
- Categorii **alimentare**; exclude categorii non-alimentare si produse alcoolice detectabile dupa nume.
- Data verificarii, sursa si un ID derivat din nume + gramaj + categorie.
- Istoric al schimbarilor de pret si produse introduse/scoase din lista publica.
- JSON/CSV direct pentru aplicatia Android sau un backend; o pagina web de cautare.

**Nu extrage:** stocuri pe magazine, promotii din cataloage, card Lidl Plus, cod EAN/SKU sau fotografii. Aceste date nu sunt disponibile in fisierul oficial XLSB. Campul `image_url` este `null` in mod normal. `config/images.json` permite asocierea manuala a unor imagini pentru care ai drepturi de folosire, dupa ID.

**Important:** verificati drepturile de reutilizare a datelor/imaginilor si conditiile Lidl inainte de lansarea comerciala. Descarcarea unui fisier public nu este o licenta automata pentru republicare sau branding.

## Pornire pe calculator

1. Instaleaza Python 3.11+.
2. Descarca/dezarhiveaza acest proiect.
3. In folderul proiectului ruleaza:

```bash
python -m pip install -r requirements.txt
python -m pytest -q
python src/lidl_scraper.py
```

In lipsa internetului sau pentru a testa un XLSB descarcat manual:

```bash
python src/lidl_scraper.py --input-file "preturiZilniceLidl.xlsb" --min-products 200
```

La prima rulare, fisierele apar in `data/` si `docs/api/lidl/`:

| Fisier | Utilizare |
|---|---|
| `lidl_products.json` | Catalog JSON cu `meta` si `products` |
| `lidl_products.csv` | CSV potrivit pentru import in baza de date |
| `lidl_meta.json` | Numar produse, ultima verificare, sursa, SHA256 |
| `lidl_changes.json` | Schimbari fata de ultima rulare |
| `data/lidl_price_history.csv` | Istoric incremental de modificari |
| `data/lidl_conflicts.json` | Randuri ambigue, cand exista |

Daca sursa nu raspunde sau formatul este schimbat, programul **nu suprascrie** catalogul vechi.

## Actualizare automata gratuita pe GitHub

1. Creeaza un **repository** GitHub (public daca vrei sa folosesti gratuit si GitHub Pages).
2. Urca **tot continutul** arhivei, inclusiv folderul ascuns `.github/workflows/`.
3. In GitHub deschide **Actions** si activeaza workflow-ul daca GitHub il solicita.
4. Selecteaza **Actualizeaza catalogul Lidl BunPlan** → **Run workflow**.
5. Verifica rezultatul si fisierele din `data/`.

Fisierul `.github/workflows/lidl-daily.yml` programeaza actualizari **zilnic la 09:30 UTC**, adica aproximativ 11:30 ora Romaniei iarna si 12:30 vara. *Lidl isi actualizeaza oficial fisierul numai luni–vineri*, asa ca in weekend scriptul poate regasi aceleasi preturi. GitHub Actions poate intarzia sau sari unele executii programate; verifica logurile si ultima data de sincronizare.

In setarile repository-ului: **Settings → Actions → General → Workflow permissions → Read and write permissions** (daca e necesar), ca botul sa poata salva JSON-ul in repo.

Pentru pagina de catalog, mergi la **Settings → Pages**, publica din ramura `main`, folderul `/docs`. Adresa va fi de tipul `https://UTILIZATOR.github.io/REPOSITORY/`. API-ul static va fi la `https://UTILIZATOR.github.io/REPOSITORY/api/lidl/lidl_products.json`. Datele sunt publice daca activezi Pages public.

## Schema produs

```json
{
  "id": "lidl-...",
  "name": "[din fisierul Lidl]",
  "size": "500g",
  "category": "[din fisierul Lidl]",
  "price_ron": 4.5,
  "price_per_kg_ron": 9.0,
  "price_per_l_ron": null,
  "image_url": null,
  "shop": "Lidl",
  "source_url": "https://www.lidl.ro/explore/assets/webPriceData/ro/preturiZilniceLidl.xlsb",
  "observed_at": "[timestamp real la import]",
  "stock_status": "unknown",
  "is_promotion": false
}
```

Valorile din exemplu sunt fictive, schema este reala. Nu prezentam imagini sau preturi inventate ca date reale.

## Integrare BunPlan Android

Nu conecta direct aplicatia fiecarui utilizator la Lidl. Ruleaza o singura sincronizare pe server/GitHub, apoi aplicatia consuma JSON-ul din hosting (ideal backend propriu cu cache) si afiseaza timestamp-ul. Pentru retele mobile, adauga cache local. Nu afisa niciodata `in_stock=true`: sursa nu contine stocuri. Pentru costul unei retete, converteste gramajele si rotunjeste la numarul de ambalaje reale.

## Limite explicite

- Fisierul oficial este sortimentul **permanent**, nu totalitatea ofertelor din Lidl.
- Denumirea, gramajul si categoria NU sunt un cod EAN; ID-ul derivat poate suferi schimbari la redenumire.
- Lista e la nivel national; nu confirma existenta produsului intr-un anumit magazin.
- Excluderea alcoolului se face dupa nume si nu poate garanta filtrarea perfecta.
- Imagini doar dintr-o sursa licentiata. Poti configura manual URL-uri prin `config/images.json`.
- Datele sunt in momentul descarcarii; nu pret live. SGR nu este inclus in pretul fisierului oficial.

## Depanare

- `Nu exista antet XLSB`: retailerul a schimbat numele coloanelor; modifica `COLUMN_ALIASES`.
- `Validarea a esuat`: probabil fisier incomplet/schimbat, catalogul vechi ramane intact.
- 403/429: respecta limitarea de acces; nu incerca ocolirea blocajelor sau automatizari agresive.
- Imaginile nu apar: normal, nu sunt in sursa XLSB.
