from src.lidl_scraper import (
    normalized, euro_decimal_to_float, extract_headers, parse_table, parse_size_price,
    product_id, make_changes, is_food
)

ROWS = [
    ["Lista de preturi Lidl RO"],
    ["Denumire comerciala", "Gramaj", "Categorie", "Pret vanzare"],
    ["Lapte UHT Exemplu", "1L", "Lactate", "5,49"],
    ["Orez Exemplu", "500g", "Produse de baza", 4.50],
    ["Sapun Exemplu", "100g", "Cosmetice", 2.0],
    ["Bere Exemplu", "500ml", "Bauturi", 3.50],
    ["Morcovi", "per kg", "Legume si Fructe", 2.49],
    [None, None, None, None],
]


def test_price_formats():
    assert euro_decimal_to_float("1.234,56 lei") == 1234.56
    assert euro_decimal_to_float("5,49") == 5.49
    assert euro_decimal_to_float("abc") is None
    assert euro_decimal_to_float(-10) is None


def test_headers_detect_non_first_row():
    assert extract_headers(ROWS)[0] == 1
    assert normalized("Brânzeturi și lactate") == "branzeturi si lactate"


def test_food_filter_and_output():
    products, stats = parse_table(ROWS, "2026-10-17T12:00:00+03:00")
    assert len(products) == 3
    assert all(p["shop"] == "Lidl" for p in products)
    assert all(p["image_url"] is None for p in products)
    assert all(p["stock_status"] == "unknown" for p in products)
    assert any(p["name"] == "Orez Exemplu" and p["price_per_kg_ron"] == 9 for p in products)
    assert stats["valid_rows_all_categories"] == 5


def test_unit_price():
    assert parse_size_price("500g", 5) == (10.0, None)
    assert parse_size_price("2x250ml", 4) == (None, 8.0)
    assert parse_size_price("per kg", 2.49) == (2.49, None)
    assert parse_size_price("pachet", 3) == (None, None)


def test_changes_are_real_and_not_stocks():
    old = [{"id": "1", "name": "Lapte", "price_ron": 5, "category": "Lactate"}]
    new = [{"id": "1", "name": "Lapte", "price_ron": 6, "category": "Lactate"}]
    ev = make_changes(old, new, "2026-10-17")
    assert ev[0]["change_type"] == "price_changed"
    assert ev[0]["old_price_ron"] == 5
    assert make_changes(new, new, "2026-10-17") == []


def test_no_food_tobacco_alcohol():
    assert not is_food("Tigari si tigarete", "Tigari")
    assert not is_food("Bauturi", "Vin alb sec")
    assert is_food("Bauturi", "Apa plata")


def test_consistent_product_key_when_price_changes():
    assert product_id("Lapte ", "1L", "Lactate") == product_id("lapte", "1 l", "lactate")


def test_fractional_size_and_no_untrusted_price_arithmetic():
    assert parse_size_price("0,5 L", 5) == (None, 10.0)
    assert parse_size_price("500 g / 1kg", 5) == (None, None)


def test_saved_data_updates_and_price_history(tmp_path, monkeypatch):
    from src import lidl_scraper as scraper
    import json
    monkeypatch.setattr(scraper, 'parse_xlsb', lambda _b, now, _images=None: parse_table(ROWS, now))
    input_file = tmp_path / 'fixture.xlsb'
    input_file.write_bytes(b'PK testfixture')
    scraper.run(tmp_path, input_file=input_file, min_products=2)
    data = json.loads((tmp_path / 'data' / 'lidl_products.json').read_text('utf-8'))
    assert len(data['products']) == 3
    assert len(json.loads((tmp_path / 'data' / 'lidl_changes.json').read_text('utf-8'))) == 3
    scraper.run(tmp_path, input_file=input_file, min_products=2)
    assert json.loads((tmp_path / 'data' / 'lidl_changes.json').read_text('utf-8')) == []
    lines = (tmp_path / 'data' / 'lidl_price_history.csv').read_text('utf-8-sig').splitlines()
    assert len(lines) == 4
